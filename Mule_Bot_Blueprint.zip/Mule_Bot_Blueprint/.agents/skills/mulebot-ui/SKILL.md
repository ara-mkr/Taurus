---
name: mulebot-ui
description: Build or refine Mule Bot frontend screens, components, themes, interactions and synthetic-data prototypes. Use when a task asks to implement the Mule UI, improve its visual quality, or follow the approved Mule design system. Do not use this as permission for backend, native capture, live integrations or later-phase work.
---

# Mule Bot UI builder

## Establish scope

Read AGENTS.md and PROJECT_STATE.json in the target repository. If they are absent, use references/ui-contract.md as provisional guidance and identify the missing project context before claiming the work meets the actual Mule spec. Read docs/03-ui-specification.md, design/tokens.css and the assigned ticket when available. Check owner approval for the active phase. Never advance a phase yourself.

State the single slice, allowed files and acceptance checks. Inspect the working tree before editing. Respect existing user changes. P0 is planning only; P1-P2 allow a simulated frontend after owner approval. No server/database, OAuth, provider calls, real sends/purchases, health data, microphone or native alarm claims in that envelope.

## Design before multiplying screens

Use the approved calm graphite/light system, restrained periwinkle accent, system UI typography, consistent spacing and accessible primitives. Prefer task rows and a clear hierarchy to decorative KPI cards. Keep the small M placeholder until original mascot assets are approved. Do not copy competitor artwork.

Implement the smallest useful component set for the assigned slice. Use deterministic fictional fixtures and example.com addresses. Label connections and effects as simulated. An unsupported demo request gets an honest fallback. Do not add unrelated pages, dependencies or clever architecture because they are in the long-term plan.

## Implement and verify

Render the actual result. Inspect the target desktop and narrow viewports, light/dark mode, keyboard focus, long content, empty/error/unknown states and reduced motion. Check the exact approval payload and truthfulness of completion labels. Run available type, behavior, build and accessibility checks. Never describe unrun checks as passing.

Use screenshots as evidence, not as decoration. Fix the largest hierarchy/readability issues before adding polish. Request an independent mulebot-ui-audit review when the slice is ready. Do not merge, commit, publish or push without authorization.

## Return

Report objective, changed files, commands/results, screenshots, limits and next eligible task. Keep the phase unchanged. Consult references/ui-contract.md for the compact quality contract; project files override its defaults when the owner has explicitly changed them.
