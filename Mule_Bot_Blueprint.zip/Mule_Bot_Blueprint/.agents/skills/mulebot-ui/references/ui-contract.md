# Compact UI contract

One assistant, five eventual destinations: Today, Ask Mule, Tasks, Memory, Connections. Build only the assigned slice. Today prioritizes Needs you, Up next, Tomorrow plan and receipt-backed activity. All preview data is fictional and labeled Demo.

Use semantic tokens, a 4-pixel spacing rhythm, body text around 14-15 pixels, modest 24-28 pixel page titles, one icon family, and clear focus states. Default graphite; light theme supported. Mascot presence is small and optional. No giant gradients, purple haze, random KPI tiles, meaningless charts, perpetual animation or unconsidered library defaults.

Approval details include exact account, recipient, content, attachment and evidence freshness. Unknown outcomes must remain visibly unknown. Buttons either work in the declared simulation or clearly identify an unavailable feature.

Review 1440/1280 desktop and 390/320 mobile widths, keyboard, dialog focus, long text, empty/error/disconnected states, contrast and reduced motion. Target 85/100 across hierarchy 20, action clarity 20, consistency 15, accessibility 15, complete/truthful states 15, original restraint 10, performance/motion 5. Any critical truthfulness or accessibility failure blocks a pass. Human visual approval remains required.
