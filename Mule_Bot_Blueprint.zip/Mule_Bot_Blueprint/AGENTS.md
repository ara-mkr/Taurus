# Mule Bot project instructions

Read PROJECT_STATE.json before planning any change. The owner, Akhil, controls scope. P0-P2 are the current frontend-only envelope; later phases are documentation, not implementation authorization. Never advance the phase or expand permissions on your own.

## Read on demand

- Product decisions: docs/01-product-and-brand.md.
- Phase acceptance: docs/02-phased-roadmap.md.
- UI work: docs/03-ui-specification.md and design/tokens.css.
- Architecture discussion only: docs/04-architecture.md.
- Coding workflow: docs/06-repo-and-coding-workflow.md.
- First bounded implementation: prompts/01-first-build.md.

## Current hard boundaries

No backend/server/database implementation, cloud provisioning, real OAuth, provider SDK connection, LLM API call, secret collection, real email sending, purchases, wearable data, microphone/screen capture, or native alarm claims. A frontend dev server is allowed after phase approval. Do not create future service folders as a pretext to implement them.

Use only synthetic fixtures and example.com addresses. Label all connections and real-world effects as simulated. An unsupported demo command gets an honest fallback. No fake "sent" or "alarm set" status outside clearly marked simulation.

## Design and implementation

Keep the workspace calm, professional and simple. Use semantic tokens, consistent typography and one icon family. No generic KPI-card dashboard, purple haze, giant gradients, decorative charts, constant mascot animation, or default-library styling left unconsidered. The M preview mark is not a final logo.

Implement one assigned slice. Avoid new dependencies unless justified. Keep state and adapter boundaries small. Do not copy competitor assets or code without recording licensing/provenance. Do not execute scripts from unreviewed remote skills or repos.

## Skills and verification

Use the relevant Mule skill: mulebot-ui for building, mulebot-ui-audit for independent review, mulebot-phase-gate for scope/gates, mulebot-action-safety for action design review. Read the actual SKILL.md when invoking; do not claim invocation from metadata alone.

Render the UI, inspect screenshots and keyboard behavior, run applicable tests, and report evidence. A passing build is not a visual audit. An audit is read-only unless editing was requested. Never invent passing tests or screenshot results.

Return objective, files changed, actual checks/results, screenshots, limitations and the next eligible task. Do not commit, push, publish, purchase, or change cloud/account settings unless explicitly authorized. Keep secrets and private data out of fixtures, logs and screenshots.
