# Mule Bot - Product and build blueprint

**Status:** planning pack and interactive visual study, not an implemented assistant.
**Prepared:** October 20, 2026. **Owner:** Akhil. **Working product name:** Mule Bot.
**Current boundary:** frontend-first, simulated data only. No backend work is authorized.

## Start here

Read `docs/00-start-here.md`, inspect `design/ui-direction.html` in a browser, and review the current phase in `PROJECT_STATE.json`. The long-form plan is `Mule_Bot_Master_Plan.md`; the PDF is its designed reading edition. Operational documents under `docs/` are the canonical editable sections used to rebuild the master.

For the first coding session, use `prompts/01-first-build.md`. It intentionally requests one bounded P1 slice, not a whole app. Do not start that slice until the P0 scope/design review is complete.

## What is included

- Phased product, brand, interface, architecture, integration, legal and launch specifications.
- A source library with 60 primary/first-party references checked October 20, 2026.
- A self-contained interactive HTML visual study using only synthetic data; no backend, provider calls or real actions.
- Proposed design tokens, initial tickets, quality rubric, decision log and test scenarios.
- AGENTS.md and CLAUDE.md instructions, phase state, four custom coding/review skills, and individual skill.zip packages.
- Local validation and skill-sync scripts, issue/PR templates and a documentation-pack check workflow.

The visual study is not a final production app, native alarm, real connector, medical tool, completed mascot, or final logo. No GitHub remote has been created. No external skill or third-party repository code has been installed or copied into the product.

## Reading paths

Product and phases: `docs/01-product-and-brand.md`, `docs/02-phased-roadmap.md`.
Design: `docs/03-ui-specification.md`, `design/tokens.css`, `design/ui-direction.html`.
Future architecture: `docs/04-architecture.md`; integration/reliability: `docs/05-integrations-and-evaluations.md`.
Coding agents and repo: `docs/06-repo-and-coding-workflow.md`; legal/launch: `docs/07-legal-launch-and-risk.md`.
Sources: `docs/08-references.md`; implementation tickets: `docs/09-initial-backlog.md`.

## Local checks

Run `python3 scripts/validate_pack.py` and `python3 scripts/sync_skills.py --check` from this directory. These validate the supplied planning assets; they are not application, medical, legal, or security certification.

Open `design/ui-direction.html` directly in a current browser. It makes no network requests and does not require a server. The preview can switch themes and inspect fictional task evidence. Its buttons only change local demonstration state. Refresh resets it.

## Skills

Canonical sources are under `.agents/skills`. Claude-compatible copies are under `.claude/skills`. See `docs/06-repo-and-coding-workflow.md` for invocation. Individually uploadable archives are in `skill-packages/<skill-name>/skill.zip`; the entire project ZIP is not a single skill.

## License and naming

See `LICENSE-DECISION.md`. Product/company names are provisional and have not received legal clearance. Palladium AI and Osmium AI already have related business uses. Select a cleared identity and a public code/asset license before launch.
