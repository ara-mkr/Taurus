# Decision log

All entries below are proposed directions awaiting owner confirmation where appropriate.

| ID | Decision | Rationale | Revisit when |
|---|---|---|---|
| ADR-001 | Frontend-only P0-P2 | Validate experience before access/security complexity | Owner explicitly unlocks later work |
| ADR-002 | React/TypeScript/Vite | Small client-oriented product; reusable desktop UI | Real server rendering requirement appears |
| ADR-003 | Calm graphite + light theme | Serious workspace; restrained original identity | User tests show readability or preference issues |
| ADR-004 | Small original alloy/mule companion | Character without a childish full-screen mascot | Small-size recognition and taste review |
| ADR-005 | Electron tentative after P2 | TypeScript reuse and desktop ecosystem | Packaging/footprint/security spike comparison |
| ADR-006 | Modular TS backend later | Avoid premature distributed complexity | Measured scaling or deployment boundaries justify split |
| ADR-007 | Relational memory first | Provenance/permissions before semantic search | Retrieval benchmark shows embedding benefit |
| ADR-008 | One wearable first | Validate wellness value and consent flow | Supported testers need another source |
| ADR-009 | Company name pending | Existing naming conflicts and uncleared domains | Proper clearance completed |
| ADR-010 | Exact approvals and receipts | Prevent guessed or unverifiable real-world actions | Provider-specific capability requires documented variation |

For each approved change add date, decision-maker, evidence, alternatives rejected and consequences. Do not retroactively describe untested choices as proven results.
